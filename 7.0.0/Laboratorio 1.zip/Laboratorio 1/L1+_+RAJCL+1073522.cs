﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{   
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy" + Nombre);

            /* COMENTARIOS*/

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy" + Nombre);
            Console.ReadKey();
        }   
    }
}
