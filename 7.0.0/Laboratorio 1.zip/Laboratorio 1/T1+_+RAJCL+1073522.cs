﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Ingrese su Nombre");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Ingrese su Edad");
            string Edad = Console.ReadLine();
            Console.WriteLine("Ingrese su Carrera");
            string Carrera = Console.ReadLine();
            Console.WriteLine("Ingrese su Carné");
            string Carné = Console.ReadLine();

            /* COMENTARIOS*/
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Soy " + Nombre + ", Tengo " + Edad + " años y estudio la carrera de " + Carrera +  ". Mi número de carné es; " + Carné);

            Console.ReadKey();
        }
    }
}
