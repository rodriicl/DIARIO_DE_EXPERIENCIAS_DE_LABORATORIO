﻿class Program
{
    static void Main(string[] args)
    {
        
                int suma = 0;
                Random num = new Random();

                int[,] matriz1 = new int[40, 50];
                for (int f = 0; f < 40; f++)
                {
                    for (int c = 0; c < 50; c++)
                    {
                        matriz1[f, c] = num.Next(10);
                        suma = suma + matriz1[f, c];
                    }
                }

                Console.WriteLine("La suma de la matriz fue de: " + suma);
                int[,] matriz2 = new int[40, 50];
                for (int f = 0; f < 40; f++)
                {
                    for (int c = 0; c < 50; c++)
                    {
                        matriz2[f, c] = num.Next(10);
                    }

                }
                int[,] matriz3 = new int[40, 50];
                for (int f = 0; f < 40; f++)
                {
                    for (int c = 0; c < 50; c++)
                    {
                        matriz3[f, c] = matriz1[f, c] + matriz2[f, c];
                        Console.Write(matriz3[f, c] + " ");
                    }
                    Console.WriteLine();
                }
        }




    }

